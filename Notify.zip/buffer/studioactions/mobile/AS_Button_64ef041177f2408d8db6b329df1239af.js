function AS_Button_64ef041177f2408d8db6b329df1239af(eventobject) {
    addImageFromDevice();
}