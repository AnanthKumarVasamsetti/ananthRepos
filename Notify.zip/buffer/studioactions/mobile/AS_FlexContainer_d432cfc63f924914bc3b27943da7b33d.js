function AS_FlexContainer_d432cfc63f924914bc3b27943da7b33d(eventobject) {
    onClickOfCreateCampaign(true);
    frmCampaign.show();
}