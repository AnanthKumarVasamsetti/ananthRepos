function addWidgetsfrmMainPage() {
    frmMainPage.setDefaultUnit(kony.flex.DP);
    var flxTitleBar = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxTitleBar",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "sknHeader2993c4",
        "top": "0%",
        "width": "100%",
        "zIndex": 4
    }, {}, {});
    flxTitleBar.setDefaultUnit(kony.flex.DP);
    var flxLoginButton = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "height": "8%",
        "id": "flxLoginButton",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox046cc831de27e43",
        "top": "70%",
        "width": "30%",
        "zIndex": 6
    }, {}, {});
    flxLoginButton.setDefaultUnit(kony.flex.DP);
    var Label047ff3936f1b149 = new kony.ui.Label({
        "centerX": "50%",
        "centerY": "50%",
        "id": "Label047ff3936f1b149",
        "isVisible": true,
        "skin": "CopyslLabel0546e9d6fca154c",
        "text": "login",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    flxLoginButton.add(
    Label047ff3936f1b149);
    var flxSkipButton = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "height": "8%",
        "id": "flxSkipButton",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox",
        "top": "80%",
        "width": "30%",
        "zIndex": 6
    }, {}, {});
    flxSkipButton.setDefaultUnit(kony.flex.DP);
    var Label0db113ad5edcc46 = new kony.ui.Label({
        "centerX": "50%",
        "centerY": "50%",
        "id": "Label0db113ad5edcc46",
        "isVisible": true,
        "skin": "CopyslLabel09c6542e90ec741",
        "text": "I'll skip",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    flxSkipButton.add(
    Label0db113ad5edcc46);
    var labNotification = new kony.ui.Label({
        "centerX": "50%",
        "id": "labNotification",
        "isVisible": false,
        "skin": "CopyslLabel0103bd071c35341",
        "text": "Recent: Campaign on KBR park cleanup Time: 10:30 AM",
        "top": "80%",
        "width": "70%",
        "zIndex": 5
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    flxTitleBar.add(
    flxLoginButton, flxSkipButton, labNotification);
    var Image0a711a93a37294b = new kony.ui.Image2({
        "centerX": "50%",
        "height": "22%",
        "id": "Image0a711a93a37294b",
        "isVisible": true,
        "skin": "slImage",
        "src": "notify.png",
        "top": "10%",
        "width": "40%",
        "zIndex": 5
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Label0a4294bc7912140 = new kony.ui.Label({
        "centerX": "50%",
        "id": "Label0a4294bc7912140",
        "isVisible": true,
        "skin": "CopyslLabel0c024d63c9fca49",
        "text": "Notify",
        "top": "28%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 5
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var flxCampaign = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "13%",
        "id": "flxCampaign",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "7.51%",
        "skin": "slFbox",
        "top": "64.00%",
        "width": "18.62%",
        "zIndex": 1
    }, {}, {});
    flxCampaign.setDefaultUnit(kony.flex.DP);
    var Image0ae2d6a43f08643 = new kony.ui.Image2({
        "height": "100%",
        "id": "Image0ae2d6a43f08643",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "campaign.png",
        "top": "0%",
        "width": "100%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxCampaign.add(
    Image0ae2d6a43f08643);
    var Label021571b1f6b4947 = new kony.ui.Label({
        "id": "Label021571b1f6b4947",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel060b8f0f7ddc946",
        "text": "Campaign",
        "top": "78%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var flxHealthCare = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "height": "12.46%",
        "id": "flxHealthCare",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox",
        "top": "65.54%",
        "width": "17.18%",
        "zIndex": 2
    }, {}, {});
    flxHealthCare.setDefaultUnit(kony.flex.DP);
    var Image0f460792ce93846 = new kony.ui.Image2({
        "centerX": "50%",
        "centerY": "50%",
        "height": "100%",
        "id": "Image0f460792ce93846",
        "isVisible": true,
        "skin": "slImage",
        "src": "heartshape.png",
        "width": "100%",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxHealthCare.add(
    Image0f460792ce93846);
    var Label08dfdef373e384d = new kony.ui.Label({
        "id": "Label08dfdef373e384d",
        "isVisible": true,
        "left": "43%",
        "skin": "CopyslLabel08d24bb2c469f4b",
        "text": "Health care",
        "top": "78%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var flxEmergency = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxEmergency",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "76%",
        "skin": "slFbox",
        "top": "65.54%",
        "width": "17%",
        "zIndex": 2
    }, {}, {});
    flxEmergency.setDefaultUnit(kony.flex.DP);
    var Image0eb42644195d04f = new kony.ui.Image2({
        "centerX": "50%",
        "centerY": "50%",
        "height": "100%",
        "id": "Image0eb42644195d04f",
        "isVisible": true,
        "skin": "slImage",
        "src": "emergency.png",
        "width": "100%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxEmergency.add(
    Image0eb42644195d04f);
    var Label0910ae096f20f44 = new kony.ui.Label({
        "id": "Label0910ae096f20f44",
        "isVisible": true,
        "left": "77%",
        "skin": "CopyslLabel0714b68f2082c47",
        "text": "Emergency",
        "top": "78%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var Label061139e827fab45 = new kony.ui.Label({
        "height": "15%",
        "id": "Label061139e827fab45",
        "isVisible": true,
        "left": "66%",
        "skin": "CopyslLabel030c77715fbd24c",
        "top": "65%",
        "width": "0.20%",
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopyLabel023313f6019e24a = new kony.ui.Label({
        "height": "15%",
        "id": "CopyLabel023313f6019e24a",
        "isVisible": true,
        "left": "33%",
        "skin": "CopyslLabel030c77715fbd24c",
        "top": "65%",
        "width": "0.20%",
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    frmMainPage.add(
    flxTitleBar, Image0a711a93a37294b, Label0a4294bc7912140, flxCampaign, Label021571b1f6b4947, flxHealthCare, Label08dfdef373e384d, flxEmergency, Label0910ae096f20f44, Label061139e827fab45, CopyLabel023313f6019e24a);
};

function frmMainPageGlobals() {
    frmMainPage = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmMainPage,
        "enabledForIdleTimeout": false,
        "id": "frmMainPage",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "preShow": AS_Form_39c9bc6deca5438980f1fb510b97fb9c,
        "skin": "sknfrmMain"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "configureExtendBottom": false,
        "configureExtendTop": false,
        "configureStatusBarStyle": false,
        "footerOverlap": false,
        "formTransparencyDuringPostShow": "100",
        "headerOverlap": false,
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
        "needsIndicatorDuringPostShow": false,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "slTitleBar"
    });
};