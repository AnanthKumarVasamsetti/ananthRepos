function addWidgetsfrmCampaign() {
    frmCampaign.setDefaultUnit(kony.flex.DP);
    var flxHeader = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "7%",
        "id": "flxHeader",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "sknHeader2993c4",
        "top": "0%",
        "width": "100%"
    }, {}, {});
    flxHeader.setDefaultUnit(kony.flex.DP);
    var lblCampList = new kony.ui.Label({
        "height": "100%",
        "id": "lblCampList",
        "isVisible": true,
        "left": "0%",
        "skin": "sknHeaderLblffffff",
        "text": "News Feed",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": "100%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var flxBackBtn = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxBackBtn",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_33566fc0c5ce4d1181370848d5ae5b8b,
        "skin": "slFbox",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {}, {});
    flxBackBtn.setDefaultUnit(kony.flex.DP);
    var Image0bf378b89714c48 = new kony.ui.Image2({
        "height": "100%",
        "id": "Image0bf378b89714c48",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "back.png",
        "top": "0%",
        "width": "100%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxBackBtn.add(
    Image0bf378b89714c48);
    flxHeader.add(
    lblCampList, flxBackBtn);
    var flexCampListScroll = new kony.ui.FlexScrollContainer({
        "allowHorizontalBounce": true,
        "allowVerticalBounce": true,
        "bounces": false,
        "clipBounds": true,
        "enableScrolling": true,
        "height": "93%",
        "horizontalScrollIndicator": true,
        "id": "flexCampListScroll",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "pagingEnabled": false,
        "scrollDirection": kony.flex.SCROLL_VERTICAL,
        "skin": "slFSbox",
        "top": "7%",
        "verticalScrollIndicator": true,
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flexCampListScroll.setDefaultUnit(kony.flex.DP);
    var segCampList = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "imgCampaign": "campaign.png",
            "lblDate": "Label",
            "lblTitle": "Campaign Title"
        }, {
            "imgCampaign": "campaign.png",
            "lblDate": "Label",
            "lblTitle": "Campaign Title"
        }, {
            "imgCampaign": "campaign.png",
            "lblDate": "Label",
            "lblTitle": "Campaign Title"
        }],
        "groupCells": false,
        "height": "99%",
        "id": "segCampList",
        "isVisible": true,
        "left": "0%",
        "needPageIndicator": true,
        "onRowClick": AS_Segment_a3c589f1b0504b70aa6390a9202a839a,
        "pageOffDotImage": "pageOffDot.png",
        "pageOnDotImage": "pageOnDot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "Copyseg0313e11a6d5eb48",
        "rowTemplate": flexTemplate,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorRequired": false,
        "showScrollbars": false,
        "top": "1%",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "FlexContainer0eef9df92304846": "FlexContainer0eef9df92304846",
            "flexTemplate": "flexTemplate",
            "flexTitle": "flexTitle",
            "imgCampaign": "imgCampaign",
            "lblDate": "lblDate",
            "lblTitle": "lblTitle"
        },
        "width": "100%"
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flexCampListScroll.add(
    segCampList);
    var flexOrganizeCampScroll = new kony.ui.FlexScrollContainer({
        "allowHorizontalBounce": true,
        "allowVerticalBounce": true,
        "bounces": false,
        "clipBounds": true,
        "enableScrolling": false,
        "height": "93%",
        "horizontalScrollIndicator": true,
        "id": "flexOrganizeCampScroll",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "110%",
        "pagingEnabled": false,
        "scrollDirection": kony.flex.SCROLL_VERTICAL,
        "skin": "sknScrollFlexffffff",
        "top": "7%",
        "verticalScrollIndicator": true,
        "width": "100%",
        "zIndex": 3
    }, {}, {});
    flexOrganizeCampScroll.setDefaultUnit(kony.flex.DP);
    var tbxName = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "height": "7%",
        "id": "tbxName",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "2.64%",
        "placeholder": "Name",
        "secureTextEntry": false,
        "skin": "CopyslTextBox0bf25ac4e7c944a",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "10%",
        "width": "90%"
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoFilter": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var lblNameBdr = new kony.ui.Label({
        "height": "0.10%",
        "id": "lblNameBdr",
        "isVisible": true,
        "left": "2.94%",
        "skin": "sknLblBorder",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "15%",
        "width": "90%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var tbxAgenda = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "height": "7%",
        "id": "tbxAgenda",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "2.64%",
        "placeholder": "Agenda",
        "secureTextEntry": false,
        "skin": "CopyslTextBox0bf25ac4e7c944a",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "18%",
        "width": "90%"
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoFilter": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var lblAgendaBdr = new kony.ui.Label({
        "height": "0.15%",
        "id": "lblAgendaBdr",
        "isVisible": true,
        "left": "2.94%",
        "skin": "sknLblBorder",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "23%",
        "width": "90%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var tbxLocation = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "height": "7%",
        "id": "tbxLocation",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "2.64%",
        "placeholder": "Location",
        "secureTextEntry": false,
        "skin": "CopyslTextBox0bf25ac4e7c944a",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "27%",
        "width": "90%"
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoFilter": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var lblLocationBdr = new kony.ui.Label({
        "height": "0.10%",
        "id": "lblLocationBdr",
        "isVisible": true,
        "left": "2.94%",
        "skin": "sknLblBorder",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "32%",
        "width": "90%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var datePicker = new kony.ui.Calendar({
        "calendarIcon": "calbtn.png",
        "dateFormat": "yyyy/MM/dd",
        "height": "7%",
        "id": "datePicker",
        "isVisible": true,
        "left": "2.45%",
        "placeholder": "Date",
        "skin": "CopyslCalendar04c18a7739a2844",
        "top": "36%",
        "viewConfig": {
            "gridConfig": {},
            "gridconfig": "",
        },
        "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
        "width": "80%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var txtAreaDesc = new kony.ui.TextArea2({
        "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
        "height": "25%",
        "id": "txtAreaDesc",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
        "left": "2.45%",
        "numberOfVisibleLines": 3,
        "placeholder": "Description",
        "skin": "slTextArea",
        "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
        "top": "45%",
        "width": "92%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [2, 2, 2, 2],
        "paddingInPixel": false
    }, {});
    var btnAddImg = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "7%",
        "id": "btnAddImg",
        "isVisible": true,
        "left": "65.00%",
        "onClick": AS_Button_64ef041177f2408d8db6b329df1239af,
        "skin": "CopyslButtonGlossRed08a07068736d14c",
        "text": "Add Image",
        "top": "77.03%",
        "width": "30%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnPostCampaign = new kony.ui.Button({
        "centerX": "50%",
        "focusSkin": "slButtonGlossRed",
        "height": "30dp",
        "id": "btnPostCampaign",
        "isVisible": true,
        "onClick": AS_Button_3885911dee36427b95de398d4e57cf47,
        "skin": "CopyslButtonGlossRed0e283771ea66f48",
        "text": "Post",
        "top": "90%",
        "width": "25%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flexOrganizeCampScroll.add(
    tbxName, lblNameBdr, tbxAgenda, lblAgendaBdr, tbxLocation, lblLocationBdr, datePicker, txtAreaDesc, btnAddImg, btnPostCampaign);
    var flxShadowOfCreate = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxShadowOfCreate",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "78%",
        "skin": "CopyslFbox02abe9742f32846",
        "top": "86%",
        "width": "20%",
        "zIndex": 1
    }, {}, {});
    flxShadowOfCreate.setDefaultUnit(kony.flex.DP);
    flxShadowOfCreate.add();
    var btnCreate = new kony.ui.Button({
        "height": "12%",
        "id": "btnCreate",
        "isVisible": true,
        "left": "79%",
        "onClick": AS_Button_a470fb962a8344f4a1f823f94f20abc0,
        "skin": "CopyslButtonGlossBlue01316f4a839a24f",
        "text": "+",
        "top": "86%",
        "width": "20%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    frmCampaign.add(
    flxHeader, flexCampListScroll, flexOrganizeCampScroll, flxShadowOfCreate, btnCreate);
};

function frmCampaignGlobals() {
    frmCampaign = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmCampaign,
        "enabledForIdleTimeout": false,
        "id": "frmCampaign",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "preShow": AS_Form_00a1d334deef42a1a0d6addd2fbce9c3,
        "skin": "sknfrmMain"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};