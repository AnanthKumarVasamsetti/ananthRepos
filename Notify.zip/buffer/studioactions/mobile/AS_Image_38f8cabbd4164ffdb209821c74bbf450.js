function AS_Image_38f8cabbd4164ffdb209821c74bbf450(eventobject, x, y) {
    frmCampaign.show();
}