function initializecampaingn() {
    flexTemplate = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "30%",
        "id": "flexTemplate",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox00762b44254534f"
    }, {}, {});
    flexTemplate.setDefaultUnit(kony.flex.DP);
    var imgCampaign = new kony.ui.Image2({
        "height": "90%",
        "id": "imgCampaign",
        "isVisible": true,
        "left": "5%",
        "skin": "slImage",
        "src": "campaign.png",
        "top": "5%",
        "width": "90%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var flexTitle = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "30%",
        "id": "flexTitle",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "5%",
        "skin": "sknFlxTitle",
        "top": "65%",
        "width": "90%",
        "zIndex": 2
    }, {}, {});
    flexTitle.setDefaultUnit(kony.flex.DP);
    var lblTitle = new kony.ui.Label({
        "id": "lblTitle",
        "isVisible": true,
        "left": "4.50%",
        "skin": "CopyslLabel090f7dbb9584c40",
        "text": "Campaign Title",
        "top": "5%",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblDate = new kony.ui.Label({
        "bottom": "7%",
        "id": "lblDate",
        "isVisible": true,
        "left": "4.50%",
        "skin": "CopyslLabel04f4b5cf6419a41",
        "text": "Label",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    flexTitle.add(
    lblTitle, lblDate);
    flexTemplate.add(
    imgCampaign, flexTitle);
}