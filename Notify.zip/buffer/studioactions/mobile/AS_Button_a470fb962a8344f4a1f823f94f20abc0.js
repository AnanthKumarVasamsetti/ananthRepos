function AS_Button_a470fb962a8344f4a1f823f94f20abc0(eventobject) {
    onClickOfCreateCampaign(false);
}