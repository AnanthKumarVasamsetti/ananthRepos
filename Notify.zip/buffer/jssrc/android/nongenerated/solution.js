function preShowFunction() {
    frmMainPage.flxTitleBar.height = "100%";
    frmMainPage.flxTitleBar.flxLoginButton.isVisible = true;
    frmMainPage.flxTitleBar.flxSkipButton.isVisible = true;
    frmMainPage.labNotification.isVisible = false;
    frmMainPage.flxSkipButton.onClick = function() {
        startUpAnimation();
    };
    /**
     * @function
     * @params: NO 
     * @Action: It navigates to the campaign news feed form 
     */
    frmMainPage.flxCampaign.onClick = function() {
        frmCampaign.show();
        //frmCampaign.flexOrganizeCampScroll.left = "110%";
    };
}

function startUpAnimation() {
    frmMainPage.flxLoginButton.isVisible = false;
    frmMainPage.flxSkipButton.isVisible = false;
    frmMainPage.labNotification.isVisible = true;
    frmMainPage.flxTitleBar.animate(kony.ui.createAnimation({
        100: {
            "height": "50%"
        }
    }), {
        fillMode: kony.anim.FILL_MODE_FORWARDS,
        duration: 0.5
    }, {
        "animationEnd": function showEvent() {}
    });
}
/**
 * @function
 *
 */
function onSegmentRowClick() {
    var selectedIndex = frmCampaign.segCampList.selectedItems[0];
    frmCampaignDescp.lblTitle.text = selectedIndex.lblTitle;
    frmCampaignDescp.lblDate.text = selectedIndex.lblDate;
    frmCampaignDescp.labDescp.text = selectedIndex.desc;
    frmCampaignDescp.imgDescp.src = selectedIndex.imgCampaign;
    frmCampaignDescp.show();
}
var img = {
    "base64": " "
};
var campaignData = [{
    "imgCampaign": "savelife.png",
    "lblTitle": "Save a Life Give a Lane",
    "lblDate": "25 May 2016",
    "desc": "The names of the patients whose lives we save can never be known. Our contribution will be what did not happen to them. And, though they are unknown, we will know that mothers and fathers are at graduations and weddings they would have missed, and that grandchildren will know grandparentsthey might never have known, and holidays will be taken, and work completed, and books read, and symphonies heard, and gardens tended that, without our work, would never have been. We invite you to join a Campaign to make health care safer and more effective "
}, {
    "imgCampaign": "changes.png",
    "lblTitle": "Changes Starts Here",
    "lblDate": "1 June 2016",
    "desc": "Sure, you’ve heard of United Way. We’re not new…but what we’re doing definitely is. We spent the past decade revolutionizing relationships between donors, volunteers, nonprofit agencies and community partners so that our efforts reach hundreds of thousands of people in groundbreaking ways. By creating strategies that solve problems at their root causes and full scale, we have become a nationally recognized leader in changing the human condition."
}, {
    "imgCampaign": "campaign.png",
    "lblTitle": "Stop.Think.Connect",
    "lblDate": "5 June 2016",
    "desc": "The Stop.Think.Connect. Campaign is a national public awareness effort among government, industry, and non-profits designed to guide the nation to a higher level of Internet security by educating and empowering the American public to be more vigilant about practicing safe online habits. The campaign will provide Girl Scouts with tools and resources to help raise awareness among kids, teens and young adults about emerging online threats and the importance of cybersecurity. This partnership builds on the campaign’s efforts to highlight curriculum resources available to communities as well as to promote cyber security awareness to millions of girls engaged in Girl Scouting. Through this relationship, the Girl Scouts of the USA will advocate and promote cybersecurity awareness across the country. Visit the DHS Stop.Think.Connect. Campaign Materials and Toolkit for information to share with adults and girls to educate them on the importance of staying safe online."
}];
/**
 * @function
 *
 */
function mapData() {
    frmCampaign.segCampList.setData(campaignData);
}
/**
 * @function
 *
 */
function onClickOfCreateCampaign(boolShowCampList) {
    var leftValue = 0;
    if (boolShowCampList === true) {
        leftValue = 110;
        frmCampaign.flxHeader.lblCampList.text = "News Feed";
        frmCampaign.btnCreate.setVisibility(true);
        frmCampaign.flxBackBtn.isVisible = false;
    } else {
        leftValue = 0;
        frmCampaign.flxHeader.lblCampList.text = "Cretae a Campaign";
        frmCampaign.btnCreate.setVisibility(false);
        frmCampaign.flxBackBtn.isVisible = true;
    }
    frmCampaign.flexOrganizeCampScroll.animate(kony.ui.createAnimation({
        100: {
            "left": leftValue + "%"
        }
    }), {
        fillMode: kony.anim.FILL_MODE_FORWARDS,
        duration: 0.5
    }, {
        "animationEnd": function showEvent() {}
    });
}
/**
 * @function
 *
 */
function addImageFromDevice() {
    var querycontext = {
        mimetype: "image/*"
    };
    var returnStatus = kony.phone.openMediaGallery(onselectioncallback, querycontext);
}
/**
 * @function
 *
 */
function onselectioncallback(rawbytes) {
    //alert("in selection callback");
    if (rawbytes === null) {
        // alert("nothing selected");
        return;
    }
    img = {
        "base64": rawbytes
    };
}
/**
 * @function
 *
 */
function onClickOfPost() {
    var tempPostDetail = {};
    if (frmCampaign.tbxAgenda.text === null || frmCampaign.tbxLocation.text === null || frmCampaign.tbxName.text === null || frmCampaign.txtAreaDesc.text === null) {
        alert("Please Fill all fields...");
    } else {
        tempPostDetail.lblTitle = frmCampaign.flexOrganizeCampScroll.tbxAgenda.text;
        tempPostDetail.lblDate = frmCampaign.flexOrganizeCampScroll.datePicker.data;
        tempPostDetail.desc = frmCampaign.flexOrganizeCampScroll.txtAreaDesc.text;
        tempPostDetail.name = frmCampaign.flexOrganizeCampScroll.tbxName.text;
        tempPostDetail.location = frmCampaign.flexOrganizeCampScroll.tbxLocation.text;
        if (img.base64 !== " ") {
            tempPostDetail.imgCampaign = img.base64;
        } else {
            tempPostDetail.imgCampaign = "campaign.png";
        }
        campaignData.push(tempPostDetail);
        mapData();
        onClickOfCreateCampaign(true);
    }
}