function addWidgetsfrmCampaignDescp() {
    frmCampaignDescp.setDefaultUnit(kony.flex.DP);
    var imgDescp = new kony.ui.Image2({
        "height": "30%",
        "id": "imgDescp",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "imagedrag.png",
        "top": "0%",
        "width": "100%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Label079a5a9d905dd42 = new kony.ui.Label({
        "id": "Label079a5a9d905dd42",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel017e483d1b0584b",
        "text": "Description:",
        "top": "2%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var labDescp = new kony.ui.Label({
        "id": "labDescp",
        "isVisible": true,
        "left": "5%",
        "maxNumberOfLines": 10,
        "skin": "CopyslLabel000cf858f4bb141",
        "text": "Label",
        "textTruncatePosition": constants.TEXT_TRUNCATE_END,
        "top": "2%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var btnJoin = new kony.ui.Button({
        "centerX": "50%",
        "focusSkin": "slButtonGlossRed",
        "height": "5%",
        "id": "btnJoin",
        "isVisible": true,
        "skin": "CopyslButtonGlossBlue0d55bcb019d384e",
        "text": "Join",
        "top": "10%",
        "width": "20%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    frmCampaignDescp.add(
    imgDescp, Label079a5a9d905dd42, labDescp, btnJoin);
};

function frmCampaignDescpGlobals() {
    frmCampaignDescp = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmCampaignDescp,
        "enabledForIdleTimeout": false,
        "id": "frmCampaignDescp",
        "layoutType": kony.flex.FLOW_VERTICAL,
        "needAppMenu": true,
        "skin": "CopyslForm092298444e9ce40"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "configureExtendBottom": false,
        "configureExtendTop": false,
        "configureStatusBarStyle": false,
        "footerOverlap": false,
        "formTransparencyDuringPostShow": "100",
        "headerOverlap": false,
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
        "needsIndicatorDuringPostShow": false,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "slTitleBar"
    });
};