function initializecampaingn() {
    flexTemplate = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "30%",
        "id": "flexTemplate",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox00762b44254534f"
    }, {}, {});
    flexTemplate.setDefaultUnit(kony.flex.DP);
    var FlexContainer0eef9df92304846 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "90%",
        "id": "FlexContainer0eef9df92304846",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0d1b2cb7251c842",
        "top": "5%",
        "width": "100%",
        "zIndex": 2
    }, {}, {});
    FlexContainer0eef9df92304846.setDefaultUnit(kony.flex.DP);
    var imgCampaign = new kony.ui.Image2({
        "height": "100%",
        "id": "imgCampaign",
        "isVisible": true,
        "left": "0.00%",
        "skin": "slImage",
        "src": "campaign.png",
        "top": "5%",
        "width": "100%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var flexTitle = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0%",
        "clipBounds": true,
        "height": "44.44%",
        "id": "flexTitle",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "sknFlxTitle",
        "width": "100%",
        "zIndex": 2
    }, {}, {});
    flexTitle.setDefaultUnit(kony.flex.DP);
    var lblTitle = new kony.ui.Label({
        "id": "lblTitle",
        "isVisible": true,
        "left": "4.50%",
        "skin": "CopyslLabel090f7dbb9584c40",
        "text": "Campaign Title",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "5%",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblDate = new kony.ui.Label({
        "bottom": "7%",
        "id": "lblDate",
        "isVisible": true,
        "left": "4.50%",
        "skin": "CopyslLabel04f4b5cf6419a41",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flexTitle.add(
    lblTitle, lblDate);
    FlexContainer0eef9df92304846.add(
    imgCampaign, flexTitle);
    flexTemplate.add(
    FlexContainer0eef9df92304846);
}