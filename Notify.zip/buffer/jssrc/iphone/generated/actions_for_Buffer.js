//actions.js file 
function AS_Button_3885911dee36427b95de398d4e57cf47(eventobject) {
    onClickOfPost();
}
function AS_Button_64ef041177f2408d8db6b329df1239af(eventobject) {
    addImageFromDevice();
}
function AS_Button_a470fb962a8344f4a1f823f94f20abc0(eventobject) {
    onClickOfCreateCampaign(0);
}
function AS_Button_d4a0afdf33644a2d82eaaa2b9ccc01a9(eventobject) {
    return sendSMS.call(this);
}
function AS_Form_00a1d334deef42a1a0d6addd2fbce9c3(eventobject) {
    mapData();
}
function AS_Form_39c9bc6deca5438980f1fb510b97fb9c(eventobject) {
    return preShowFunction.call(this);
}
function AS_Image_38f8cabbd4164ffdb209821c74bbf450(eventobject, x, y) {
    frmCampaign.show();
}