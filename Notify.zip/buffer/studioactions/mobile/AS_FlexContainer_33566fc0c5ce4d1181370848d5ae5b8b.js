function AS_FlexContainer_33566fc0c5ce4d1181370848d5ae5b8b(eventobject) {
    onClickOfCreateCampaign(true);
}