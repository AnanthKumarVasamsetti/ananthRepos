function addWidgetsfrmHealthCare() {
    frmHealthCare.setDefaultUnit(kony.flex.DP);
    var flxHeader = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "7%",
        "id": "flxHeader",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "sknHeader2993c4",
        "top": "0%",
        "width": "100%"
    }, {}, {});
    flxHeader.setDefaultUnit(kony.flex.DP);
    var lblCampList = new kony.ui.Label({
        "height": "100%",
        "id": "lblCampList",
        "isVisible": true,
        "left": "0%",
        "skin": "sknHeaderLblffffff",
        "text": "Health care",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": "100%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var flxBackBtn = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxBackBtn",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_8a041b2bb00241d4822ae2fa7413fa73,
        "skin": "slFbox",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {}, {});
    flxBackBtn.setDefaultUnit(kony.flex.DP);
    var Image0bf378b89714c48 = new kony.ui.Image2({
        "height": "100%",
        "id": "Image0bf378b89714c48",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "back.png",
        "top": "0%",
        "width": "100%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxBackBtn.add(
    Image0bf378b89714c48);
    flxHeader.add(
    lblCampList, flxBackBtn);
    var Map0ebd9652fe7bc42 = new kony.ui.Map({
        "calloutWidth": 80,
        "defaultPinImage": "pinb.png",
        "height": "54.87%",
        "id": "Map0ebd9652fe7bc42",
        "isVisible": true,
        "left": "0dp",
        "locationData": [{
            "desc": "Phoenix infocity, Gachibowli",
            "lat": "17.447326",
            "lon": "78.371358",
            "name": "KonyLabs(New)"
        }, {
            "desc": "Mindspace, Hitech City",
            "lat": "17.441839",
            "lon": "78.380928",
            "name": "KonyLabs(Old)"
        }, {
            "desc": "Orlando, US",
            "lat": "28.449340",
            "lon": "-81.481519",
            "name": "KonyLabs"
        }],
        "provider": constants.MAP_PROVIDER_GOOGLE,
        "top": "46dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {
        "mode": constants.MAP_VIEW_MODE_NORMAL,
        "showZoomControl": true,
        "zoomLevel": 15
    });
    var Label002c7c3c881404e = new kony.ui.Label({
        "id": "Label002c7c3c881404e",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel0d47300bc313b41",
        "text": "Demo:",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "65%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Label03fe89897799a41 = new kony.ui.Label({
        "id": "Label03fe89897799a41",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel08203a5dc8ee042",
        "text": "This form leads to the near by healthcare services by providing necessary details like near by hospitals and sending a notification for the ambulance drives within 5KMs distance and alerting them to reach the victim spot.",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "70%",
        "width": "90%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    frmHealthCare.add(
    flxHeader, Map0ebd9652fe7bc42, Label002c7c3c881404e, Label03fe89897799a41);
};

function frmHealthCareGlobals() {
    frmHealthCare = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmHealthCare,
        "enabledForIdleTimeout": false,
        "id": "frmHealthCare",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "skin": "CopyslForm0a209994eab0e47"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_RESIZE
    });
};