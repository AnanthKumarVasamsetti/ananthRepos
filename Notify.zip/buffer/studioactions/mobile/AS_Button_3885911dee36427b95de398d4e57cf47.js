function AS_Button_3885911dee36427b95de398d4e57cf47(eventobject) {
    onClickOfPost();
}