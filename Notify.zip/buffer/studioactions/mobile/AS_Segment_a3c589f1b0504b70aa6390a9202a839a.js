function AS_Segment_a3c589f1b0504b70aa6390a9202a839a(eventobject, sectionNumber, rowNumber) {
    onSegmentRowClick();
}