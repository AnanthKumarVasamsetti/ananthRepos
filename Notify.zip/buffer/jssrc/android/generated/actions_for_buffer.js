//actions.js file 
function AS_Button_3885911dee36427b95de398d4e57cf47(eventobject) {
    onClickOfPost();
}
function AS_Button_64ef041177f2408d8db6b329df1239af(eventobject) {
    addImageFromDevice();
}
function AS_Button_a470fb962a8344f4a1f823f94f20abc0(eventobject) {
    onClickOfCreateCampaign(false);
}
function AS_Button_d4a0afdf33644a2d82eaaa2b9ccc01a9(eventobject) {
    return sendSMS.call(this);
}
function AS_FlexContainer_115344078b06410ab605f6cb5d71f24d(eventobject) {
    frmEmergency.show();
}
function AS_FlexContainer_21406309a1fc419d88d79becde791132(eventobject) {
    frmMainPage.show();
}
function AS_FlexContainer_33566fc0c5ce4d1181370848d5ae5b8b(eventobject) {
    onClickOfCreateCampaign(true);
}
function AS_FlexContainer_8a041b2bb00241d4822ae2fa7413fa73(eventobject) {
    frmMainPage.show();
}
function AS_FlexContainer_ba619401afc34674b90f5923274f9259(eventobject) {
    frmHealthCare.show();
}
function AS_FlexContainer_bb4f8fcd73494a7ba4d02385330947ff(eventobject) {
    frmCampaign.flexOrganizeCampScroll.left = "110%";
    mapData();
    frmCampaign.show();
}
function AS_FlexContainer_d432cfc63f924914bc3b27943da7b33d(eventobject) {
    onClickOfCreateCampaign(true);
    frmCampaign.show();
}
function AS_Form_00a1d334deef42a1a0d6addd2fbce9c3(eventobject) {
    mapData();
}
function AS_Form_39c9bc6deca5438980f1fb510b97fb9c(eventobject) {
    return preShowFunction.call(this);
}
function AS_Form_4ccd7f96c2154d21bd6de824c6425f71(eventobject) {
    return preShowFunction.call(this);
}
function AS_Image_38f8cabbd4164ffdb209821c74bbf450(eventobject, x, y) {
    frmCampaign.show();
}
function AS_Segment_a3c589f1b0504b70aa6390a9202a839a(eventobject, sectionNumber, rowNumber) {
    onSegmentRowClick();
}